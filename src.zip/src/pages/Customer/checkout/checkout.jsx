import React from "react";
import { CustomerLayout } from "../../../components";

const Checkout = () => {
  return <CustomerLayout>Checkout</CustomerLayout>;
};
export default Checkout;
