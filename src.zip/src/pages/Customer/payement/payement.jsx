import React from "react";
import { CustomerLayout } from "../../../components";

const Payement = () => {
  return <CustomerLayout>this is payment page</CustomerLayout>;
};
export default Payement;
