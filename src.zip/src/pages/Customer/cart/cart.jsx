import React from "react";
import { CustomerLayout } from "../../../components";
const Cart = () => {
  return <CustomerLayout>Cart</CustomerLayout>;
};
export default Cart;
