import React from "react";
import { CustomerLayout } from "../../../components";
const Home = () => {
  return <CustomerLayout>this is main part</CustomerLayout>;
};
export default Home;
