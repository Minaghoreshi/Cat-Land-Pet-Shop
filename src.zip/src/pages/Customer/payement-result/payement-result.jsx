import React from "react";
import { CustomerLayout } from "../../../components";
const PayementResult = () => {
  return <CustomerLayout>this is Payement Result page</CustomerLayout>;
};
export default PayementResult;
