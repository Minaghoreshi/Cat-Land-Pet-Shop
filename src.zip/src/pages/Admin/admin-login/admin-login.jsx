import React from "react";
import { LoginLayout } from "../../../components/base";
const AdminLogin = ({ shouldNavigate }) => {
  return <LoginLayout shouldNavigate={shouldNavigate} />;
};
export default AdminLogin;
