import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { QueryClient, QueryClientProvider } from "react-query";
import { store } from "./store";
import { Provider } from "react-redux";
import { Dispatch } from "@reduxjs/toolkit";
import { login } from "./features/auth/authThunk";
const root = ReactDOM.createRoot(document.getElementById("root"));
const queryClient = new QueryClient();
const accessToken = localStorage.getItem("token");
const refreshToken = localStorage.getItem("refreshToken");

if (accessToken && refreshToken) {
  // Dispatch the login action and wait for it to complete
  store.dispatch(login()).then(() => {
    // After the login action is complete, log the current auth state
    const state = store.getState();
    // console.log(state.auth);
  });
}

root.render(
  <Provider store={store}>
    <QueryClientProvider client={queryClient}>
      <React.StrictMode>
        <App />
      </React.StrictMode>{" "}
    </QueryClientProvider>
  </Provider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
