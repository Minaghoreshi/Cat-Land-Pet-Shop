import AppRoute from "./routes/routs";

function App() {
  return <AppRoute />;
}

export default App;
