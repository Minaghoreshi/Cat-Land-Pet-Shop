import React from "react";

export const AdminFooter = () => {
  return <div>AdminFooter</div>;
};
