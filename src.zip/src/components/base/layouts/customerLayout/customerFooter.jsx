import React from "react";

export const CustomerFooter = () => {
  return <div>CustomerFooter</div>;
};
