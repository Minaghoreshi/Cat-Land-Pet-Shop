import React from "react";

export const TableTitle = ({ button, title }) => {
  return <span className="text-3xl ">{title} </span>;
};
