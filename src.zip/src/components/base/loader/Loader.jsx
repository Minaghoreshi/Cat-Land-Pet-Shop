import React from "react";

export const Loader = () => {
  return <div>Loading...</div>;
};
